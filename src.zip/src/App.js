
import { BrowserRouter,Routes,Route } from "react-router-dom";
import Register from "./components/Register";
import Login from "./components/Login";
 
import Home from "./components/Home";
import Forgotpassword from "./components/Forgotpassword";
import Resetpassword from "./components/Resetpassword";
import Admindashboard from "./components/Admindashboard";
import AllUsers from "./components/AllUsers";



function App() {
  return (
    <div>

      <BrowserRouter>
            <Routes>
              <Route path="/" element= { <Home/>} />
              <Route path="/register" element= { <Register/>} />
              <Route path="/login" element= { <Login/>} />
              <Route path="/forgotpassword" element={<Forgotpassword/>}/>
              <Route path="/resetpassword" element={<Resetpassword/>}/>
              <Route path="/admin" element={<Admindashboard />}/>
            {/* Nested route for Users */}
            <Route path="/admin/users" element={<AllUsers />} />
          
              {/* <Route path="/admin" element={<Admindashboard/>}/> */}
              {/* <Route path="/admin/users" element={<AllUsers/>}/> */}
              {/* <Route path="/admin/pending-users" component={PendingUsers} />
              <Route path="/admin/approved-users" component={ApprovedUsers} />
              <Route path="/admin/rejected-users" component={RejectedUsers} /> */}
            </Routes>
        </BrowserRouter>
      
    </div>
  );
}


export default App;
