import { useState } from "react";
import { Link } from 'react-router-dom';
import axios from "axios";
import "./Register.css";

function Register() {

    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [businessName, setBusinessName] = useState("");
    const [phoneNumber, setPhoneNumber] = useState("");
    const [modeOfBusiness, setModeOfBusiness] = useState("");
    const [category, setCategory] = useState("");
    const [errors, setErrors] = useState({});
    

    const validateName = (value) => {
        if (!value.trim()) {
            return "Name is required";
        } else if (!/^[A-Za-z\s]+$/.test(value)) {
            return "Name should only contain letters";
        }
        return "";
    };

    const validateEmail = (value) => {
        if (!value.trim()) {
            return "Email is required";
        } else if (!/\S+@\S+\.\S+/.test(value)) {
            return "Invalid email address";
        }
        return "";
    };

    const validatePassword = (value) => {
        if (!value.trim()) {
            return "Password is required";
        } else if (value.length < 8) {
            return "Password should be at least 8 characters long";
        } else if (!/[A-Z]/.test(value)) {
            return "Password should contain at least one uppercase letter";
        } else if (!/[a-z]/.test(value)) {
            return "Password should contain at least one lowercase letter";
        } else if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+/.test(value)) {
            return "Password should contain at least one special character";
        }
        return "";
    };

    const validateBusinessName = (value) => {
        if (!value.trim()) {
            return "Business Name is required";
        } else if (!/^[A-Za-z\s]+$/.test(value)) {
            return "Business Name should only contain letters";
        }
        return "";
    };

    const validatePhoneNumber = (value) => {
        if (!value.trim()) {
            return "Phone Number is required";
        } else if (!/^\d{10}$/.test(value)) {
            return "Phone Number should be exactly 10 digits";
        }
        return "";
    };
   

    const validateForm = () => {
        const nameError = validateName(name);
        const emailError = validateEmail(email);
        const passwordError = validatePassword(password);
        const businessNameError = validateBusinessName(businessName);
        const phoneNumberError = validatePhoneNumber(phoneNumber);
        const errors = {
            name: nameError,
            email: emailError,
            password: passwordError,
            businessName: businessNameError,
            phoneNumber: phoneNumberError,
            modeOfBusiness: "",
            category: "",
        };
        return errors;
    };

    const handleChange = (event) => {
        const { name, value } = event.target;
        const validationFunc =
            name === "name" ? validateName :
                name === "email" ? validateEmail :
                    name === "password" ? validatePassword :
                        name === "businessName" ? validateBusinessName :
                            name === "phoneNumber" ? validatePhoneNumber :
                                null;
        if (validationFunc) {
            setErrors((prevErrors) => ({
                ...prevErrors,
                [name]: validationFunc(value),
            }));
        }
    
        switch (name) {
            case "name":
                setName(value);
                break;
            case "email":
                setEmail(value);
                break;
            case "password":
                setPassword(value);
                break;
            case "businessName":
                setBusinessName(value);
                break;
            case "phoneNumber":
                setPhoneNumber(value);
                break;
            case "modeOfBusiness":
                setModeOfBusiness(value);
                break;
            case "category":
                setCategory(value);
                break;
            default:
                break;
        }
    };

    const save = async (event) => {
        event.preventDefault();
        const formErrors = validateForm();
        if (Object.values(formErrors).some((error) => error)) {
            setErrors(formErrors);
            return;
        }
        try {
            await axios.post("http://localhost:8080/api/users", {
                name: name,
                email: email,
                password: password,
                businessName: businessName,
                phoneNumber: phoneNumber,
                modeOfBusiness: modeOfBusiness,
                category: category,
            });
            alert("Registration Successful");
        } catch (err) {
            alert(err);
        }
    };

    return (
        <div>
            <div className="container">
                <div className="card ">
                    <h1 className=" text-center">Register Here</h1>
                    <form>
                        <div className="form-group">
                            <label>Name</label>
                            <input
                                type="text"
                                className="form-control"
                                name="name"
                                value={name}
                                onChange={handleChange}
                            />
                            {errors.name && <small className="text-danger">{errors.name}</small>}
                        </div>
                        <div className="form-group">
                            <label>Email</label>
                            <input
                                type="email"
                                className="form-control"
                                name="email"
                                value={email}
                                onChange={handleChange}
                            />
                            {errors.email && <small className="text-danger">{errors.email}</small>}
                        </div>
                        <div className="form-group">
                            <label>Password</label>
                            <input
                                type="password"
                                className="form-control"
                                name="password"
                                value={password}
                                onChange={handleChange}
                            />
                            {errors.password && <small className="text-danger">{errors.password}</small>}
                        </div>
                        <div className="form-group">
                            <label>Business Name</label>
                            <input
                                type="text"
                                className="form-control"
                                name="businessName"
                                value={businessName}
                                onChange={handleChange}
                            />
                            {errors.businessName && <small className="text-danger">{errors.businessName}</small>}
                        </div>
                        <div className="form-group">
                           
                            <label class="control-label">Phone Number</label>
                            <input
                                inputMode="numeric"
                                name="phoneNumber"

                                className="form-control"
                                maxLength="10"
                                onInput={(event) => event.target.value = event.target.value.replace(/\D+/g, '')}
                                value={phoneNumber}
                                onChange={handleChange}
                            />
                            {errors.phoneNumber && <small className="text-danger">{errors.phoneNumber}</small>} {/* Display email error */}
                        </div>
                        <div className="form-group">
                            <label>Mode of Business</label>
                            <div>
                                <label style={{ fontWeight: "normal", marginRight: "20px" }}>
                                    <input
                                        type="radio"
                                        name="modeOfBusiness"
                                        value="Product"
                                        checked={modeOfBusiness === "Product"}
                                        onChange={handleChange}
                                    /> Product
                                </label>
                                <label style={{ fontWeight: "normal" }}>
                                    <input
                                        type="radio"
                                        name="modeOfBusiness"
                                        value="Service"
                                        checked={modeOfBusiness === "Service"}
                                        onChange={handleChange}
                                    /> Service
                                </label>
                            </div>
                            {errors.modeOfBusiness && <small className="text-danger">{errors.modeOfBusiness}</small>}
                        </div>
                        <div className="form-group">
                            <label>Category</label>
                            <select
                                className="form-control"
                                name="category"
                                value={category}
                                onChange={handleChange}
                            >
                                <option value="">Select a category</option>
                                <option value="Technology">Technology</option>
                                <option value="Food Court">Food Court</option>
                                <option value="Light and Sounds">Light and Sounds</option>
                                <option value="Promotion and Marketing">Promotion and Marketing</option>
                            </select>
                            {errors.category && <small className="text-danger">{errors.category}</small>}
                        </div>
                        <button type="submit" className="btn btn-primary mt-4" onClick={save} >Register</button>
                        <Link to="/login">Login</Link>
                    </form>
                </div>
            </div>
        </div>
    );
}

export default Register;
