import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';


function ResetComponent() {
    useEffect(() => {
        const urlParams = new URLSearchParams(window.location.search);
        const email = urlParams.get('email');
        const token = urlParams.get('token');
        
        if (email) setEmail(email);
        if (token) setToken(token);
    }, []);

    const [email, setEmail] = useState('');
    const [token, setToken] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    //const [error, setError] = useState('');
    const [PasswordError, setPasswordError] = useState(''); 
    const [confirmPasswordError, setConfirmPasswordError] = useState('');
    const navigate=useNavigate();

    const reset = async (event) => {
        event.preventDefault();
        if (!newPassword || !confirmPassword) {
            // Set error messages for empty fields
            setPasswordError(newPassword ? "" : "Password is required");
            setConfirmPasswordError(confirmPassword ? "" : "This field is required"); // Fix typo here
            // Additional required fields can be handled similarly
            return;
        }

        try {
            const response = await axios.post("http://localhost:8080/api/users/reset", {
                newPassword: newPassword,
                confirmPassword: confirmPassword,
                email: email,
                resetToken: token
            });
            
         
            toast.success("Password Reset Successfully");
            setTimeout(() => navigate('/'), 1000);
        }
        catch (err) {
            //setError(err.message || err.response.data || "An error occurred");
        }
        if (newPassword !== confirmPassword) {
            setConfirmPasswordError('Passwords do not match');
            return;
        }
    }
    return (
        <div>
            <div className="row d-flex align-items-center justify-content-center mt-5">
                <div className="col-md-4 ">
                    <form onSubmit={reset}>
                        {/* Hidden inputs for email and token */}
                        <input type="hidden" value={email} />
                        <input type="hidden" value={token} />
                        <div className="form-group">
                            <label className="control-label">New Password</label>
                            <input className="form-control" type="password" value={newPassword} onChange={(event) => {setNewPassword(event.target.value)
                                 const isValidPassword = /^(?=\D*\d)(?=[^a-z]*[a-z])(?=[^A-Z]*[A-Z]).{8,30}$/.test(event.target.value);
                                 if (!isValidPassword && event.target.value !== '') {
                                     setPasswordError('Password must be at least 8 characters long and should contain at least one uppercase letter, one lowercase letter, one number, and a special character ');
                                 } else {
                                     setPasswordError('');
                                 }
              
              
              
              
              }              
                                
                            } />
                            {PasswordError && <small className="text-danger">{PasswordError}</small>} {/* Display password error */}
                        </div>
                        <div className="form-group">
                            <label className="control-label">Confirm Password</label>
                            <input className="form-control" type="password" value={confirmPassword} onChange={(event) => {setConfirmPassword(event.target.value)
                                 setConfirmPasswordError('');
                            } }/>
                            {confirmPasswordError && <small className="text-danger">{confirmPasswordError}</small>}
                        </div>
                        {/* {error && <div className="alert alert-danger">{error}</div>} */}
                        <div class="mt-3 mb-1">
                            <input type="submit" value="Reset Password" className="btn btn-primary btn-block" />
                        </div>
                    </form>
                </div>
            </div>
        </div>
    )
}

export default ResetComponent