import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './AllUsers.css';
import './AllUsers.css';
import { toast , ToastContainer} from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

function Pendingusers() {
    const [users, setUsers] = useState([]);

    useEffect(() => {
        const fetchUsers = async () => {
            try {
                const response = await axios.get('http://localhost:8080/api/users/pending');
                setUsers(response.data);
            } catch (error) {
                console.error('Error fetching users:', error);
            }
        };

        fetchUsers();
    }, []);
    const approveUser = async (id) => {
        // if (window.confirm("Are you sure you want to approve this user?")) {
        try {
            const userConfirmed =window.confirm("Are you sure you want to approve this registration?");
            if (userConfirmed) {
            await axios.put(`http://localhost:8080/api/users/${id}/approve`);
            // Remove the approved user from the list
            setUsers(users.filter(user => user.id !== id));
            toast.success('Approved Successfully')
            }
        } catch (error) {
            console.error('Error approving user:', error);
        }
    }
    

    const rejectUser = async (id) => {
        
        try {
            const userConfirmed =window.confirm("Are you sure you want to reject this registration?");
            if (userConfirmed) {
            await axios.put(`http://localhost:8080/api/users/${id}/reject`);
            // Remove the rejected user from the list
            setUsers(users.filter(user => user.id !== id));
            toast.success('Rejected Successfully')
            }
        } catch (error) {
            console.error('Error rejecting user:', error);
        }
    }

    return (
        
        <div className="row d-flex align-items-center justify-content-center mt-5">
        <ToastContainer position="top-center" />
            <h1>Pending Users</h1>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                    </tr>
                </thead>
                <tbody>
                    {users.map(user => (
                        <tr key={user.id}>
                            <td>{user.id}</td>
                            <td>{user.name}</td>
                            <td>{user.email}</td>
                            <td>
                                <button onClick={() => approveUser(user.id)}>Approve</button>
                                <button onClick={() => rejectUser(user.id)}>Reject</button>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>

    );
 
}
export default Pendingusers;
