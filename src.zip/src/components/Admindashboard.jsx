import React, { useState } from 'react';
import './Admindashboard.css';
import AllUsers from './AllUsers';
import Pendingusers from './Pendingusers';
import RejectedUsers from './RejectedUsers';
import ApprovedUsers from './ApprovedUsers';

function Admindashboard() {
    const [selectedComponent, setSelectedComponent] = useState(null);

    const handleNavigation = (component) => {
        setSelectedComponent(component);
    };

    return (
        <div className="admin-dashboard">
            {/* Sidebar */}
            <div className="admin-sidebar">
                <h1 className='text-center'>Dashboard</h1>
                <ul>
                    <li>
                        <h5 onClick={() => handleNavigation(<AllUsers />)}>Users</h5>
                    </li>
                    <li>
                        <h5 onClick={() => handleNavigation(<Pendingusers />)}>Pending Users</h5>
                    </li>
                    <li>
                        <h5 onClick={() => handleNavigation(<ApprovedUsers />)}>Approved Users</h5>
                    </li>
                    <li>
                        <h5 onClick={() => handleNavigation(<RejectedUsers />)}>Rejected Users</h5>
                    </li>
                </ul>
            </div>

            {/* Main Content Area */}
            <div className="admin-content">
           
                {selectedComponent}
            </div>
        </div>
    );
}

export default Admindashboard;
