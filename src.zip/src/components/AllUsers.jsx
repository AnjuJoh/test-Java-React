import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './AllUsers.css';
// import { toast,ToastContainer } from 'react-toastify';
import { toast ,ToastContainer} from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

function AllUsers() {
    const [users, setUsers] = useState([]);

    useEffect(() => {
        const fetchUsers = async () => {
            try {
                const response = await axios.get('http://localhost:8080/api/users');
                setUsers(response.data);
            } catch (error) {
                console.error('Error fetching users:', error);
            }
        };

        fetchUsers();
    }, []);
    const deleteUser = async (id) => {
        try {
            const userConfirmed =window.confirm("Are you sure you want to delete this registration?");
            if (userConfirmed) {
                
                await axios.delete(`http://localhost:8080/api/users/${id}`);
                
               
                setUsers(prevRegistrations => prevRegistrations.filter(reg => reg.id !== id));
                
                
                toast.success("Vendor deleted successfully!");
            }
        } catch (error) {
           
            console.error("Error deleting registration:", error);
            
            
            toast.error("Error deleting registration. Please try again later.");
        }
    };
    
    return (
        <div className="row d-flex align-items-center justify-content-center mt-5">
            <ToastContainer position="top-center" />
      
            <h1>All Users</h1>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                    </tr>
                </thead>
                <tbody>
                    {users.map(user => (
                        <tr key={user.id}>
                            <td>{user.id}</td>
                            <td>{user.name}</td>
                            <td>{user.email}</td>
                            <td>
                                <button onClick={() => deleteUser(user.id)}>Delete</button>
                            </td> 
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
}

export default AllUsers;
