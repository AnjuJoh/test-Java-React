import { useState } from "react";
// import { useNavigate } from 'react-router-dom';
import axios from "axios";
import './Forgotpassword.css';

function Forgotpassword() {
    const [email, setEmail] = useState("");

    // const navigate = useNavigate();

    async function forgot(event) {
        event.preventDefault();
        try {
            const res = await axios.post(`http://localhost:8080/api/users/forgot-password`, { email });
            if (res.data === "Password reset instructions sent to your email.") {
                alert("Password reset instructions sent to your email.");
            } else if (res.data === "User with provided email not found.") {
                alert("User with provided email not found.");
            } else {
                alert("An error occurred while processing your request.");
            }
        } catch (err) {
            alert("An error occurred while processing your request.");
        }
    }

    return (
       <div>
            <div className="container2">
                <div className="card2">
                    <h1 className="mb-7 text-center">Forgot</h1>
               
                        <form>
                            <div className="form-group2">
                                <label>Email</label>
                                <input type="email" className="form-control" id="email" placeholder="Enter email"
                                    value={email}
                                    onChange={(event) => {
                                        setEmail(event.target.value);
                                    }}
                                />
                            </div>
                            
                            <button type="submit" className="btn btn-primary" onClick={forgot}>Send Reset Email</button>
                        </form>
                    </div>
                </div>
            </div>
       
    );
}

export default Forgotpassword;
