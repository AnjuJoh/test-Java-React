import React, { useState } from "react";
import { useNavigate, Link } from 'react-router-dom';
import axios from "axios";
import "./Login.css"; 

function Login() {
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [emailError, setEmailError] = useState("");
    const [passwordError, setPasswordError] = useState("");
    const navigate = useNavigate();

    const validateEmail = (value) => {
        if (!value.trim()) {
            setEmailError("Email is required");
        } else {
            setEmailError("");
        }
    };

    const validatePassword = (value) => {
        if (!value.trim()) {
            setPasswordError("Password is required");
        } else {
            setPasswordError("");
        }
    };

    const handleChangeEmail = (event) => {
        const value = event.target.value;
        setEmail(value);
        validateEmail(value);
    };

    const handleChangePassword = (event) => {
        const value = event.target.value;
        setPassword(value);
        validatePassword(value);
    };

    const login = async (event) => {
        event.preventDefault();

        if (!emailError && !passwordError) {
            try {
                const res = await axios.get(`http://localhost:8080/authenticateUser/${email}/${password}`);
                if (res.data.role === "1") {
                    navigate('/admin');
                } else {
                    navigate('/');
                }
            } catch (err) {
                alert("Incorrect Email or Password!"); // Display error message from the backend
            }
        }
    };

    return (
        <div>
            <div className="container1">
                <div className="card1">
                    <h1 className="text-center">Login Here</h1>
                    <form>
                        <div className="form-group1">
                            <label>Email</label>
                            <input 
                                type="email" 
                                className={"form-control" + (emailError ? " is-invalid" : "")} 
                                placeholder="Enter email"
                                value={email}
                                onChange={handleChangeEmail}
                            />
                            {emailError && <div className="invalid-feedback">{emailError}</div>}
                        </div>
                        <div className="form-group1">
                            <label>Password</label>
                            <input 
                                type="password" 
                                className={"form-control" + (passwordError ? " is-invalid" : "")} 
                                placeholder="Enter password"
                                value={password}
                                onChange={handleChangePassword}
                            />
                            {passwordError && <div className="invalid-feedback">{passwordError}</div>}
                        </div>
                        <button type="submit" className="btn btn-primary" onClick={login}>Login</button><br /><br />
                        <div className="text-center">
                            <Link to="/forgotpassword">Forgot Password?</Link><br />
                            <Link to="/register">Register</Link>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    );
}

export default Login;
