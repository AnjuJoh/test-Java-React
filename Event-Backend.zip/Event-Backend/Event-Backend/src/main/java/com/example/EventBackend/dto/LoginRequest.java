package com.example.EventBackend.dto;

public class LoginRequest {
    private String email;


    // Constructor, getters, and setters

    public LoginRequest() {
    }

    public LoginRequest(String email) {
        this.email = email;

    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

}
