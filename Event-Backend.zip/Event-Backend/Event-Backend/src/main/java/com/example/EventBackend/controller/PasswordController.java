package com.example.EventBackend.controller;

import com.example.EventBackend.dto.LoginRequest;
import com.example.EventBackend.dto.ResetPasswordRequest;
import com.example.EventBackend.entity.User;
import com.example.EventBackend.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.UUID;

@RestController
@CrossOrigin("*")
@RequestMapping("/api/users")
public class PasswordController {
    private static final Logger logger = LoggerFactory.getLogger(PasswordController.class);
    private final UserRepository userRepository;
    @Autowired
    private final JavaMailSender emailSender;

    public PasswordController(UserRepository userRepository, JavaMailSender emailSender) {
        this.userRepository = userRepository;
        this.emailSender = emailSender;
    }

    @PostMapping("/forgot-password")
    public ResponseEntity<String> forgotPassword(@RequestBody LoginRequest loginRequest) {
        String email = loginRequest.getEmail();
        User user = userRepository.findByEmail(email);
        if (user != null) {
            String resetToken = generateResetToken();
            user.setResetToken(resetToken); // Set the reset token for the user
            userRepository.save(user);
            sendResetPasswordEmail(user, resetToken,email);
            return new ResponseEntity<>("Password reset instructions sent to your email.", HttpStatus.OK);
        } else {
            return new ResponseEntity<>("User with provided email not found.", HttpStatus.NOT_FOUND);
        }
    }


//    @PostMapping("/reset-password")
//    public ResponseEntity<String> resetPassword(@RequestBody ResetPasswordRequest request) {
//        User user = userRepository.findByEmailAndResetToken(request.getEmail(), request.getToken());
//        if (user != null && isValidToken(user, request.getToken())) {
//            if(request.getPassword().equals(request.getConfirmPassword())) {
//                user.setPassword(request.getPassword());
//                user.setResetToken(null);
//                userRepository.save(user);
//                return new ResponseEntity<>("Password reset successfully.", HttpStatus.OK);
//            } else {
//                return new ResponseEntity<>("New password and confirm password do not match.", HttpStatus.BAD_REQUEST);
//            }
//        } else {
//            return new ResponseEntity<>("Invalid token or user not found.", HttpStatus.BAD_REQUEST);
//        }
//    }

    private void sendResetPasswordEmail(User user, String resetToken,String email) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(user.getEmail());
        message.setSubject("Password Reset Instructions");
        message.setText("Please click on the link below to reset your password:\n"
                + "http://localhost:3000/resetpassword?email="+email +"&token=" + resetToken);
        emailSender.send(message);
    }

//    private boolean isValidToken(User user, String token) {
//        return user.getResetToken().equals(token);
//    }
//
    private String generateResetToken() {
        return UUID.randomUUID().toString();
    }
}
