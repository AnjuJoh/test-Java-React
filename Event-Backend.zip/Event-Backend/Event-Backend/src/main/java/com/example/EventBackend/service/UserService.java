package com.example.EventBackend.service;

import com.example.EventBackend.entity.User;

import java.util.List;
import java.util.Optional;

public interface UserService {
    List<User> getAllUsers();

    Optional<User> getUserById(Long id);
    List<User> getAllPendingUsers();
    List<User> getAllApprovedUsers();
    List<User> getAllRejectedUsers();
    void deleteUser(Long id);
    Optional<User> findByEmail(String email);
//    boolean isValidToken(User user, String token);
//    void resetPassword(String email, String token, String password,String confirmPassword);
//    Optional<User> findByEmailAndResetToken(String email, String resetToken);
//    Optional<User> findByEmailAndPassword(String email, String password);
}
