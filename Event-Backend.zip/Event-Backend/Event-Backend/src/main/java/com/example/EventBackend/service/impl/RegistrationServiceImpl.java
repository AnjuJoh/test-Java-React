package com.example.EventBackend.service.impl;

import com.example.EventBackend.dto.RegistrationUserDto;
import com.example.EventBackend.entity.Register;
import com.example.EventBackend.entity.User;
import com.example.EventBackend.repository.RegisterRepository;
import com.example.EventBackend.repository.UserRepository;
import com.example.EventBackend.service.RegistrationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class RegistrationServiceImpl implements RegistrationService {
    @Autowired
    private RegisterRepository registerRepository;

    @Autowired
    private UserRepository userRepository;

    @Override
    public RegistrationUserDto createUser(RegistrationUserDto registrationUserDto) {
        User user = new User();
        user.setName(registrationUserDto.getName());
        user.setEmail(registrationUserDto.getEmail());
        user.setPassword(registrationUserDto.getPassword());
        user.setRole("2");
        userRepository.save(user);

        Register register = new Register();
        register.setBusinessName(registrationUserDto.getBusinessName());
        register.setCategory(registrationUserDto.getCategory());
        register.setPhoneNumber(registrationUserDto.getPhoneNumber());
        register.setModeOfBusiness(registrationUserDto.getModeOfBusiness());
        register.setUser(user);

        registerRepository.save(register);

        return registrationUserDto;
    }
    @Override
    public void approveRegistration(Long id) {
        Register register = registerRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid registration Id:" + id));
        register.setStatus("APPROVED");
        registerRepository.save(register);
    }

    @Override
    public void rejectRegistration(Long id) {
        Register register = registerRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid registration Id:" + id));
        register.setStatus("REJECTED");
        registerRepository.save(register);
    }
    }

