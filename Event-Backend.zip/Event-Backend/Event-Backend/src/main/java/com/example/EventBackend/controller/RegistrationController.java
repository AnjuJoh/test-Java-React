package com.example.EventBackend.controller;

import com.example.EventBackend.dto.RegistrationUserDto;
import com.example.EventBackend.entity.User;
import com.example.EventBackend.repository.UserRepository;
import com.example.EventBackend.service.RegistrationService;
import lombok.AllArgsConstructor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@AllArgsConstructor
@RestController
@CrossOrigin("*")
@RequestMapping("/api/users")
public class RegistrationController {

    private final RegistrationService registrationService;
    private final UserRepository userRepository;

    private static final Logger log = LogManager.getLogger(RegistrationController.class);

    @PostMapping
    public ResponseEntity<RegistrationUserDto> createUser(@RequestBody RegistrationUserDto registrationUserDto) {
        RegistrationUserDto savedUser = registrationService.createUser(registrationUserDto);
        log.info("Created user: {}", savedUser);
        return new ResponseEntity<>(savedUser, HttpStatus.CREATED);
    }

    @GetMapping
    public ResponseEntity<List<RegistrationUserDto>> getAllUsers() {
        List<RegistrationUserDto> users = userRepository.findAll().stream()
                .map(user -> new RegistrationUserDto(
                        user.getId(),
                        user.getName(),
                        user.getEmail(),
                        user.getPassword(),
                        user.getRole(),
                        user.getRegister().getBusinessName(),
                        user.getRegister().getPhoneNumber(),
                        user.getRegister().getCategory(),
                        user.getRegister().getModeOfBusiness()
                ))
                .collect(Collectors.toList());
      
        return new ResponseEntity<>(users, HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<RegistrationUserDto> getUserById(@PathVariable Long id) {
        Optional<User> optionalUser = userRepository.findById(id);
        if (optionalUser.isPresent()) {
            User user = optionalUser.get();
            RegistrationUserDto registrationUserDto = new RegistrationUserDto(
                    user.getId(),
                    user.getName(),
                    user.getEmail(),
                    user.getPassword(),
                    user.getRole(),
                    user.getRegister().getBusinessName(),
                    user.getRegister().getPhoneNumber(),
                    user.getRegister().getCategory(),
                    user.getRegister().getModeOfBusiness()
            );
          
            return new ResponseEntity<>(registrationUserDto, HttpStatus.OK);
        } else {
           
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteUser(@PathVariable Long id) {
        userRepository.deleteById(id);
       
        return new ResponseEntity<>("User deleted successfully", HttpStatus.OK);
    }

    @GetMapping("/pending")
    public ResponseEntity<List<RegistrationUserDto>> getAllPendingUsers() {
        List<RegistrationUserDto> users = userRepository.findAll().stream()
                .filter(user -> "PENDING".equals(user.getRegister().getStatus()))
                .map(user -> new RegistrationUserDto(
                        user.getId(),
                        user.getName(),
                        user.getEmail(),
                        user.getPassword(),
                        user.getRole(),
                        user.getRegister().getBusinessName(),
                        user.getRegister().getPhoneNumber(),
                        user.getRegister().getCategory(),
                        user.getRegister().getModeOfBusiness()
                ))
                .collect(Collectors.toList());
      
        return new ResponseEntity<>(users, HttpStatus.OK);
    }

    @PutMapping("/{id}/approve")
    public ResponseEntity<String> approveRegistration(@PathVariable Long id) {
        registrationService.approveRegistration(id);
       
        return new ResponseEntity<>("Registration approved successfully", HttpStatus.OK);
    }

    @GetMapping("/approved")
    public ResponseEntity<List<RegistrationUserDto>> getAllApprovedUsers() {
        List<RegistrationUserDto> users = userRepository.findAll().stream()
                .filter(user -> "APPROVED".equals(user.getRegister().getStatus()))
                .map(user -> new RegistrationUserDto(
                        user.getId(),
                        user.getName(),
                        user.getEmail(),
                        user.getPassword(),
                        user.getRole(),
                        user.getRegister().getBusinessName(),
                        user.getRegister().getPhoneNumber(),
                        user.getRegister().getCategory(),
                        user.getRegister().getModeOfBusiness()
                ))
                .collect(Collectors.toList());
       
        return new ResponseEntity<>(users, HttpStatus.OK);
    }

    @PutMapping("/{id}/reject")
    public ResponseEntity<String> rejectRegistration(@PathVariable Long id) {
        registrationService.rejectRegistration(id);
       
        return new ResponseEntity<>("Registration rejected successfully", HttpStatus.OK);
    }

    @GetMapping("/rejected")
    public ResponseEntity<List<RegistrationUserDto>> getAllRejectedUsers() {
        List<RegistrationUserDto> users = userRepository.findAll().stream()
                .filter(user -> "REJECTED".equals(user.getRegister().getStatus()))
                .map(user -> new RegistrationUserDto(
                        user.getId(),
                        user.getName(),
                        user.getEmail(),
                        user.getPassword(),
                        user.getRole(),
                        user.getRegister().getBusinessName(),
                        user.getRegister().getPhoneNumber(),
                        user.getRegister().getCategory(),
                        user.getRegister().getModeOfBusiness()
                ))
                .collect(Collectors.toList());
      
        return new ResponseEntity<>(users, HttpStatus.OK);
    }
}
