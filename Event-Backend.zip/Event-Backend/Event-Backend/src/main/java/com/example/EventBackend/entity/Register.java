package com.example.EventBackend.entity;

import jakarta.persistence.*;


@Entity
@Table(name = "registration")
public class Register {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "business_name")
    private String businessName;
    @Column(name = "phone_number")
    private String phoneNumber;
    private String category;
    @Column(name = "mode_of_business")
    private String modeOfBusiness;
    @OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "User_Id",referencedColumnName = "Id" )
    private  User user;
    @Column(nullable = false)
    private String status = "PENDING";
    public void setUser(User user) {
        this.user = user;
    }

    public User getUser() {
        return user;
    }

    public Register(String status) {
        this.status = status;
    }

    public Register(Long id, String businessName, String phoneNumber, String category, String modeOfBusiness) {
        this.id = id;
        this.businessName = businessName;
        this.phoneNumber = phoneNumber;
        this.category = category;
        this.modeOfBusiness = modeOfBusiness;
    }

    public Register() {

    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getBusinessName() {
        return businessName;
    }

    public void setBusinessName(String businessName) {
        this.businessName = businessName;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getModeOfBusiness() {
        return modeOfBusiness;
    }

    public void setModeOfBusiness(String modeOfBusiness) {
        this.modeOfBusiness = modeOfBusiness;
    }


}
