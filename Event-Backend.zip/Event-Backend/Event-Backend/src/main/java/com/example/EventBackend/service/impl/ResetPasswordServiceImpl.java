package com.example.EventBackend.service.impl;

import com.example.EventBackend.dto.ResetPasswordRequest;
import com.example.EventBackend.entity.User;
import com.example.EventBackend.repository.UserRepository;
import com.example.EventBackend.service.ResetPasswordService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ResetPasswordServiceImpl implements ResetPasswordService {
    @Autowired
    private UserRepository userRepository;

    @Override
    public User resetPassword(ResetPasswordRequest resetRequest) {
        if (resetRequest.getEmail() == null || resetRequest.getResetToken() == null) {
            return null;
        }

        User registration = userRepository.findByEmail(resetRequest.getEmail());
        if (registration == null) {
            return null; // User not found
        }


        if (!resetRequest.getResetToken().equals(registration.getResetToken()) ){

            return null;

        }
        registration.setPassword(resetRequest.getNewPassword());
        return userRepository.save(registration);
    }
}



