package com.example.EventBackend.repository;

import com.example.EventBackend.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User,Long> {
    User findByEmail(String email);

public User findByEmailAndPassword(String email, String password);
    User findByEmailAndResetToken(String email, String resetToken);
}
