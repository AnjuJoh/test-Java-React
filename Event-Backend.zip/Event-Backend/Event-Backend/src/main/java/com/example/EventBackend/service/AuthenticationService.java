package com.example.EventBackend.service;

import com.example.EventBackend.entity.User;

public interface AuthenticationService {
    public User authenticateUser(String email, String password) throws Exception;
}
