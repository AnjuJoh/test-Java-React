package com.example.EventBackend.controller;

import com.example.EventBackend.entity.User;
import com.example.EventBackend.service.impl.AuthenticationServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.Optional;

@RestController
@CrossOrigin("*")
public class AuthenticationController {

    @Autowired
    AuthenticationServiceImpl authenticationServiceImpl;


//    @GetMapping("/authenticateUser/{email}/{password}")
//    public ResponseEntity<String> authenticateUser(@PathVariable String email, @PathVariable  String password) throws Exception {
//        Optional<User> user = Optional.ofNullable(authenticationServiceImpl.authenticateUser(email, password));
//        if (user.isPresent()) {
//
//            return new ResponseEntity<>("Success", HttpStatus.OK);
//
//        } else {
//            return new ResponseEntity<>("Email or Password not Exists!", HttpStatus.OK);
//        }
//    }
@GetMapping("/authenticateUser/{email}/{password}")
public ResponseEntity<User> authenticateUser(@PathVariable String email, @PathVariable String password) throws Exception {
    User user = authenticationServiceImpl.authenticateUser(email, password);
    return ResponseEntity.ok(user);
}

}
