package com.example.EventBackend.service;

import com.example.EventBackend.dto.ResetPasswordRequest;
import com.example.EventBackend.entity.User;

import java.util.Optional;

public interface ResetPasswordService {

    User resetPassword(ResetPasswordRequest resetRequest);
}
