package com.example.EventBackend.service.impl;

import com.example.EventBackend.entity.User;
import com.example.EventBackend.repository.UserRepository;
import com.example.EventBackend.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserServiceImpl implements UserService {
    @Autowired
    private UserRepository userRepository;
    @Override
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    @Override
    public Optional<User> getUserById(Long id) {
        return userRepository.findById(id);
    }

    @Override
    public List<User> getAllPendingUsers() {
        return userRepository.findAll();
    }
    @Override
    public List<User> getAllApprovedUsers() {
        return userRepository.findAll();
    }
    @Override
    public List<User> getAllRejectedUsers() {
        return userRepository.findAll();
    }



    @Override
    public void deleteUser(Long id) {
        userRepository.deleteById(id);
    }


    @Override
    public Optional<User> findByEmail(String email) {
        return Optional.ofNullable(userRepository.findByEmail(email));
    }

//    @Override
//    public boolean isValidToken(User user, String token) {
//        if (user == null || user.getResetToken() == null) {
//            return false;
//        }
//        return user.getResetToken().equals(token);
//    }



//    @Override
//    public void resetPassword(String email, String token, String password, String confirmPassword) {
//        Optional<User> optionalUser = Optional.ofNullable(userRepository.findByEmailAndResetToken(email, token));
//        optionalUser.ifPresent(user -> {
//            if (isValidToken(user, token)) {
//                if (password.equals(confirmPassword)) {
//                    user.setPassword(password);
//                    userRepository.save(user);
//                } else {
//                    throw new IllegalArgumentException("New password and confirm password do not match");
//                }
//            } else {
//                throw new IllegalArgumentException("Invalid token");
//            }
//        });
//    }

//    @Override
//    public Optional<User> findByEmailAndResetToken(String email, String resetToken) {
//        return Optional.ofNullable(userRepository.findByEmailAndResetToken(email, resetToken));
//    }


//    @Override
//    public Optional<User> findByEmailAndPassword(String email, String password) {
//        return userRepository.findByEmailAndPassword(email, password);
//    }
}
