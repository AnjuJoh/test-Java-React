package com.example.EventBackend.service;

import com.example.EventBackend.dto.RegistrationUserDto;

public interface RegistrationService {

    RegistrationUserDto createUser(RegistrationUserDto registrationUserDto);
    void approveRegistration(Long id);

    void rejectRegistration(Long id);
}
