package com.example.EventBackend.controller;

import com.example.EventBackend.dto.ResetPasswordRequest;
import com.example.EventBackend.entity.User;
import com.example.EventBackend.service.ResetPasswordService;
import com.example.EventBackend.service.impl.ResetPasswordServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;




@RestController
@CrossOrigin("*")
@RequestMapping("/api/users")
public class ResetPasswordController {

   @Autowired
   private ResetPasswordServiceImpl resetPasswordServiceImpl;

    @PostMapping("/reset")
    public ResponseEntity<String> resetPassword(@RequestBody ResetPasswordRequest resetRequest) {
        // Call the resetPassword method from the service
        if (!resetRequest.getNewPassword().equals(resetRequest.getConfirmPassword())) {
            return ResponseEntity.badRequest().body("New password and confirm password do not match");
        }

        User registration = resetPasswordServiceImpl.resetPassword(resetRequest);

        if (registration != null) {
            return ResponseEntity.ok("Password reset successfully");
        } else {
            return ResponseEntity.badRequest().body("Invalid email or reset token");
        }
    }

    }





