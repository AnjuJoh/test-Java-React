package com.example.EventBackend.service.impl;

import com.example.EventBackend.entity.User;
import com.example.EventBackend.repository.UserRepository;
import com.example.EventBackend.service.AuthenticationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AuthenticationServiceImpl implements AuthenticationService {

    @Autowired
    private UserRepository userRepository;

//    public User authenticateUser(String email, String password) throws Exception {
//
//        User user = userRepository.findByEmailAndPassword(email, password);
//
//        if (user == null) {
//            throw new Exception("invalid");
//        }
//
//        return user;
//
//    }
public User authenticateUser(String email, String password) throws Exception {
    User user = userRepository.findByEmailAndPassword(email, password);
    if (user == null) {
        throw new Exception("invalid");
    }
    return user;
}





}
